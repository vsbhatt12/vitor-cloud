
import { Component, OnInit } from '@angular/core';
import { StarWarsClientApiService } from '../../services/star-wars-client-api.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Subscription } from 'rxjs';
import { People } from '../../models/people.model';
import * as _ from 'lodash';

@Component({
  selector: 'app-landing-list',
  templateUrl: './landing-list.component.html',
  styleUrls: ['./landing-list.component.css']
})
export class LandingListComponent implements OnInit {

  subscription = new Subscription();
  people: People[] = [];
  filteredPeople: People[] = [];
  searchText = '';

  constructor(
    private _starWarsClientAPIService: StarWarsClientApiService,
    private _spinnerService: Ng4LoadingSpinnerService
  ) { }

  ngOnInit(): void {
    this.getPeople();
  }

  /**
   * @returns void
   */
  getPeople(): void {
    this._spinnerService.show();
    this._starWarsClientAPIService.getPeople().subscribe((response: People[]) => {
      this.people = response;
      this.filteredPeople = response;
      this._spinnerService.hide();
    }, () => this._spinnerService.hide());
  }

  /**
   * filter people by typing in search text box
   * text = typed value
   */
  filterPeople() {
    this.filteredPeople = [];
    this.people.forEach(user => {
      if (user.name.toLowerCase().indexOf(this.searchText.toLowerCase()) > -1) {
        this.filteredPeople.push(user);
      };
    });

  }

  clearFilter() {
    this.filteredPeople = this.people;
    this.searchText = '';
  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
