import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PublicLayoutComponent } from './public-layout.component';
import { LandingListComponent } from './components/landing-list/landing-list.component';

const routes: Routes = [
  {
    path: '', component: PublicLayoutComponent,
    children: [
      { path: 'users', component: LandingListComponent }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PublicRoutingModule { }
