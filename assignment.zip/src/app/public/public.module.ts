import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PublicLayoutComponent } from './public-layout.component';

import { PublicRoutingModule } from './public-routing.module';
import { LandingListComponent, } from './components';
import { SharedModule } from '../shared/shared.module';
import { StarWarsClientApiService } from './services/star-wars-client-api.service';
import { FormsModule } from '@angular/forms';

@NgModule({
  imports: [
    CommonModule,
    PublicRoutingModule,
    SharedModule,
    FormsModule
  ],
  declarations: [PublicLayoutComponent, LandingListComponent],
  providers: [StarWarsClientApiService]
})
export class PublicModule { }
