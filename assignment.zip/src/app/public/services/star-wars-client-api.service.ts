import { Injectable } from '@angular/core';
import { HttpClientService } from 'src/app/shared/services/http/http-client.service';
import { mergeMap } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { People } from '../models/people.model';

@Injectable()
export class StarWarsClientApiService {
    constructor(private _httpService: HttpClientService) { }

    getPeople(): Observable<People[]> {
        return this._httpService.get(`people/`)
            .pipe(mergeMap(async (response: any) => {
                return response.results;
            }));
    }
}
