// Angular core and common components
import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HTTP_INTERCEPTORS, HttpClientModule, HttpClient } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// configuration related service
import { environment } from '../environments/environment';

// main component
import { AppComponent } from './app.component';

// main routing module
import { AppRoutingModule } from './app-routing.module';

// services and guards
import { AuthGuard } from './shared/guards/auth.guard';

// External plugins
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { ToastrModule } from 'ng6-toastr-notifications';

// Services and guards
import { HttpClientService } from './shared/services/http/http-client.service';
import { ResponseInterceptor } from './shared/services/http/response-interceptor';
import { HttpResponseHandler } from './shared/services/http/httpResponseHandler.service';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    AppRoutingModule,
    BrowserModule,
    HttpClientModule,
    Ng4LoadingSpinnerModule.forRoot(),
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [
    AuthGuard,
    HttpClientService,
    {
      provide: HTTP_INTERCEPTORS,
      useClass: ResponseInterceptor,
      multi: true
    },
    HttpResponseHandler
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
