// Angular common and core module
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

// Routes of the module
import { AuthRoutingModule } from './auth-routing.module';

// Components for the module
import { LoginComponent } from './components/login/login.component';
import { HttpClient } from '@angular/common/http';


@NgModule({
  imports: [
    CommonModule,
    AuthRoutingModule, // Add routes of only auth module

    // Modules to use forms
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [LoginComponent],
  providers: []
})
export class AuthModule { }
