// Angular core and common modules
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Components for the module
import { LoginComponent } from './components/login/login.component';

// Add path of the components here
const routes: Routes = [
  {
    path: 'login',
    component: LoginComponent
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRoutingModule { }
