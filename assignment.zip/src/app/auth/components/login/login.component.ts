import { Component, OnInit, OnDestroy, Inject } from '@angular/core';
import { Validators, FormGroup, FormBuilder } from '@angular/forms';
// tslint:disable-next-line: import-blacklist
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';
import LoginForm from '../../models/login-form.model';
import { ToastrManager } from 'ng6-toastr-notifications';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  public loginForm: FormGroup;

  constructor(private _formBuilder: FormBuilder, private _router: Router, private notificationsService: ToastrManager) {
  }

  ngOnInit() {
    localStorage.setItem('loginCred', JSON.stringify({ username: 'Admin', password: btoa('Admin@123') }))
    // declaring form
    this.loginForm = this._formBuilder.group({
      username: ['', [Validators.required]],
      password: ['', Validators.required]
    });
  }

  // redirect to users page
  onSubmit() {
    const loginDetails: LoginForm = JSON.parse(localStorage.getItem('loginCred'));
    const loginFormValues: LoginForm = this.loginForm.value;
    if (loginDetails.username === loginFormValues.username && atob(loginDetails.password) === loginFormValues.password) {
      this._router.navigate(['/public/users']);
      this.loginForm.reset(); // Reset form
    }
    else {
      this.notificationsService.errorToastr('Invalid username or password');
    }
  }
}
