import { Injectable } from '@angular/core';
import {
  HttpInterceptor, HttpRequest, HttpHandler,
  HttpEvent, HttpResponse
} from '@angular/common/http';

import { Observable, BehaviorSubject } from 'rxjs';
import { map, catchError } from "rxjs/operators";
import { HttpResponseHandler } from './httpResponseHandler.service';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Injectable()
export class ResponseInterceptor implements HttpInterceptor {
  isRefreshingToken: boolean;
  tokenSubject: BehaviorSubject<string> = new BehaviorSubject<string>(null);


  constructor(private _responseHandler: HttpResponseHandler,
    private spinnerService: Ng4LoadingSpinnerService) {
    this.isRefreshingToken = false;
  }

  addToken(req: HttpRequest<any>, token: string): HttpRequest<any> {
    if (typeof req.body === 'string') {
      if (req.body.indexOf('grant_type') !== -1) {
        return req;
      }
    } else if (req.body && typeof (req.body) === 'object') {
      if (req.body.hasOwnProperty('grant_type')) {
        return req;
      }
    }

    if (req.headers.get('Authorization')) {
      return req;
    }

    if (token) {
      req = req.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`
        }
      });
      return req;
    } else {
      return req;
    }
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    this.spinnerService.show();
    return next.handle(req).pipe(
      map((event: HttpEvent<any>) => {
        this.spinnerService.hide();
        if (event instanceof HttpResponse) {
          return event;
        }
      }), catchError((error: any) => {
        // call on catch and handle response
        this._responseHandler.onCatch(error);
        return Observable.throw(error.statusText);
      }));
  }

}
