// Angular core and common modules
// tslint:disable-next-line: import-blacklist
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

// Toaster message service injected
import { ToastrManager } from 'ng6-toastr-notifications';

@Injectable()
export class HttpResponseHandler {
    constructor(
        private router: Router,
        private notificationsService: ToastrManager
    ) {
    }

    /**
     * Global http error handler.
     *
     * @param error
     * @param source
     * @returns {ErrorObservable}
     */
    public onCatch(response: any): Observable<any> {
        switch (response.status) {

            case 400:
                // The server did not understand the request.
                this.handleBadRequest(response);
                break;

            case 401:
                // The requested page needs a username and a password.
                this.handleUnauthorized(response);
                break;

            case 403:
                // Access is forbidden to the requested page.
                this.handleForbidden(response);
                break;

            case 404:
                // The server can not find the requested page.
                this.handleNotFound();
                break;

            case 500:
                // The request was not completed. The server met an unexpected condition.
                this.handleInternalServerError(response);
                break;

            case 422:
                // Any validation error from server
                this.handleUnprocessableEntity(response);
                break;

            default:
                break;
        }

        return response;
    }

    /**
     * Shows notification errors when server response status is 401
     *
     * @param error
     */
    private handleBadRequest(responseBody: any): void {
        this.notificationsService.errorToastr('Bad request')
    }

    /**
     * Shows notification errors when server response status is 401 and redirects user to login page
     *
     */
    private handleUnauthorized(responseBody): void {
        this.notificationsService.errorToastr('Unauthorized')
        this.router.navigate(['/auth/login']);
        localStorage.clear();
    }

    /**
     * Shows notification errors when server response status is 403
     */
    private handleForbidden(response): void {
        this.notificationsService.errorToastr('Forbidden URL')
    }
    /**
     * Shows notification errors when server response status is 422
     */
    private handleUnprocessableEntity(responseBody: any): void {
        this.notificationsService.errorToastr('Something went wrong');
    }

    /**
    * Shows notification errors when server response status is 500
    */
    private handleInternalServerError(response): void {
        this.notificationsService.errorToastr('internal servcer error');
    }

    /**
     * Shows notification errors when server response status is 404
     *
     * @param responseBody
     */
    private handleNotFound(): void {
        this.notificationsService.errorToastr('not found')
    }
}
