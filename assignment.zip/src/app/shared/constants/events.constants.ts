export const EventConstants = {
    displayLoading: 'displayLoading',
    filterStarship: 'filterStarship',
    filterSpecies: 'filterSpecies',
    filterHomeworld: 'filterHomeworld'    
};
